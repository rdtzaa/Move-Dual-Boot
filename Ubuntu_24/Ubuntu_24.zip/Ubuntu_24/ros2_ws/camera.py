import cv2

# Membuka kamera pertama (indeks 0, jika ada lebih dari satu kamera, bisa coba ganti indeks)
cap = cv2.VideoCapture(0)

# Cek jika kamera berhasil dibuka
if not cap.isOpened():
    print("Gagal membuka kamera.")
    exit()

while True:
    # Membaca frame dari kamera
    ret, frame = cap.read()
    
    if not ret:
        print("Gagal membaca frame.")
        break
    
    # Menampilkan gambar kamera dalam jendela OpenCV
    cv2.imshow('Gambar Kamera', frame)
    
    # Menunggu 1 ms dan menunggu pengguna menekan tombol 'q' untuk keluar
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Menutup kamera dan semua jendela OpenCV
cap.release()
cv2.destroyAllWindows()
