// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef IMAGE_TRANSPORT_TUTORIALS__MSG__RESIZED_IMAGE_HPP_
#define IMAGE_TRANSPORT_TUTORIALS__MSG__RESIZED_IMAGE_HPP_

#include "image_transport_tutorials/msg/detail/resized_image__struct.hpp"
#include "image_transport_tutorials/msg/detail/resized_image__builder.hpp"
#include "image_transport_tutorials/msg/detail/resized_image__traits.hpp"
#include "image_transport_tutorials/msg/detail/resized_image__type_support.hpp"

#endif  // IMAGE_TRANSPORT_TUTORIALS__MSG__RESIZED_IMAGE_HPP_
