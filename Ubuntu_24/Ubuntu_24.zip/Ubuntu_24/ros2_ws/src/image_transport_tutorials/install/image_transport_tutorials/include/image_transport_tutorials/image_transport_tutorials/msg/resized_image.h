// generated from rosidl_generator_c/resource/idl.h.em
// with input from image_transport_tutorials:msg/ResizedImage.idl
// generated code does not contain a copyright notice

#ifndef IMAGE_TRANSPORT_TUTORIALS__MSG__RESIZED_IMAGE_H_
#define IMAGE_TRANSPORT_TUTORIALS__MSG__RESIZED_IMAGE_H_

#include "image_transport_tutorials/msg/detail/resized_image__struct.h"
#include "image_transport_tutorials/msg/detail/resized_image__functions.h"
#include "image_transport_tutorials/msg/detail/resized_image__type_support.h"

#endif  // IMAGE_TRANSPORT_TUTORIALS__MSG__RESIZED_IMAGE_H_
