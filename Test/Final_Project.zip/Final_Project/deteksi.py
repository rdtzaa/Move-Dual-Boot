import cv2
import numpy as np
import sys
import time
from pyzbar.pyzbar import decode
# import serial

# arduino = serial.Serial('COM6', 9600)
# time.sleep(2)

# def terima_jarak():
#     if arduino.in_waiting > 0:
#         jarak_byte = arduino.read(4)
#         jarak = int.from_bytes(jarak_byte, byteorder='little')
#         return jarak
#     return 0

def olah_direction(frame, bound_box, min_area=35000):
    center = (640, 360)
    status = (bound_box[0] + bound_box[2] // 2, bound_box[1] + bound_box[3] // 2)
    cv2.line(frame, center, status, (0,255,0), 2)
    

    if status[0] > center[0] + 25:
        print("Gerak roda kanan (arah kanan)")
    elif status[0] < center[0] - 25:
        print("Gerak roda kiri (arah kiri)")
    elif bound_box[2] * bound_box[3] > min_area + 5000 or bound_box[1] < 330:
        print("Trial cocokkan dengan arm (mundur)")
    elif bound_box[2] * bound_box[3] < min_area - 5000 or bound_box[1] > 390:
        print("Trial cocokkan dengan arm (maju)")
    else: 
        print("Diam")
    # elif status[0] > center[0] + 25:
    #     print("Gerak roda kanan (arah kiri)")
    # elif status[0] < center[0] - 25:
    #     print("Gerak roda kiri (arah kanan)")


def detect_and_display_color(frame):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    white_lower_color = np.array([13,0,198]) #Batas bawah putih
    white_upper_color = np.array([52,26,255]) #Batas Atas (sesuaikan)
    blue_lower_color = np.array([78,60,0]) #Batas bawah putih
    blue_upper_color = np.array([123,255,76]) 

    mask = cv2.inRange(hsv, white_lower_color, white_upper_color)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if contours:
        max_area = -1
        max_area_idx = 0
        
        for i, contour in enumerate(contours):
            area = cv2.contourArea(contour)
            if area > max_area:
                max_area = area
                max_area_idx = i

        x, y, w, h = cv2.boundingRect(contours[max_area_idx])
        rect = (x, y, w, h)

        # # tinggi_obj = 377
        # focal_length = 7.09
        # distance = (1/((1/focal_length)-(1/rect[3]))) 

        cv2.rectangle(frame, (rect[0], rect[1]), (rect[0] + rect[2], rect[1] + rect[3]), (0, 255, 0), 2)
        cv2.putText(frame, f'Area: {rect[2] * rect[3]}, y: {rect[1]}', (rect[0], rect[1] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

        olah_direction(frame, rect)

    else:
        print('Tidak terbaca orang-orang an')

    cv2.imshow('Man Hunter', frame)

def cari_qr(frame):
    for barcode in decode(frame):
        mydata = barcode.data.decode('utf-8')
        print(mydata)
        point = np.array([barcode.polygon], np.int32)
        # point = point.reshape((-1,1,2))
        cv2.polylines(frame,[point],True,(255,0,255), 5)
    # cv2.imshow('Man Hunter', frame)

# Contoh penggunaan
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        break
    
    detect_and_display_color(frame)
    cari_qr(frame)
    # jarak = terima_jarak()
    # if jarak > 15:
    #     detect_and_display_color(frame)
    # else:
    #     cari_qr()

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
