#include "ros/ros.h"
#include "std_msgs/String.h"
#include "tutorial_messages/Message2.h"

void chatterCallback(const tutorial_messages::Message2::ConstPtr& msg) //package::variabel::nama
{
//   ROS_INFO("I heard: [%s]", msg->data.c_str());
    ROS_INFO("increment: %d, decrement: %d", msg->increment, msg->decrement);
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "listener");
  ros::NodeHandle n;
  ros::Subscriber sub = n.subscribe("chatter", 1000, chatterCallback);
  ros::spin();

  return 0;
}