// Auto-generated. Do not edit!

// (in-package tutorial_messages.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Message2 {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.increment = null;
      this.decrement = null;
    }
    else {
      if (initObj.hasOwnProperty('increment')) {
        this.increment = initObj.increment
      }
      else {
        this.increment = 0;
      }
      if (initObj.hasOwnProperty('decrement')) {
        this.decrement = initObj.decrement
      }
      else {
        this.decrement = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Message2
    // Serialize message field [increment]
    bufferOffset = _serializer.int16(obj.increment, buffer, bufferOffset);
    // Serialize message field [decrement]
    bufferOffset = _serializer.int16(obj.decrement, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Message2
    let len;
    let data = new Message2(null);
    // Deserialize message field [increment]
    data.increment = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [decrement]
    data.decrement = _deserializer.int16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'tutorial_messages/Message2';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '4cf144aafc69b8cce9450afd35d4e5ec';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int16 increment
    int16 decrement
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Message2(null);
    if (msg.increment !== undefined) {
      resolved.increment = msg.increment;
    }
    else {
      resolved.increment = 0
    }

    if (msg.decrement !== undefined) {
      resolved.decrement = msg.decrement;
    }
    else {
      resolved.decrement = 0
    }

    return resolved;
    }
};

module.exports = Message2;
