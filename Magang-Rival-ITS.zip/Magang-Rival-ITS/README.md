# Magang-Rival-ITS

Penugasan selama magang di tim robotik RIVAL ITS
