import cv2
import numpy as np

def olah_direction(bound_box, min_area=12000):
    center = (320, 240)
    status = (bound_box[0] + bound_box[2] / 2, bound_box[1] + bound_box[3] / 2)
    print("Diam")

    if bound_box[2] * bound_box[3] > min_area + 5000 or bound_box[1] < 180:
        print("Trial cocokkan dengan arm (mundur)")
    elif bound_box[2] * bound_box[3] < min_area - 5000 or (bound_box[1] + bound_box[3]) > 430:
        print("Trial cocokkan dengan arm (maju)")
    elif status[0] > center[0] + 25:
        print("Gerak roda kanan (arah kiri)")
    elif status[0] < center[0] - 25:
        print("Gerak roda kiri (arah kanan)")


def detect_and_display_color(frame):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    lower_color = np.array([0, 100, 100]) #Batas bawah
    upper_color = np.array([10, 255, 255]) #Batas Atas (sesuaikan)

    mask = cv2.inRange(hsv, lower_color, upper_color)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if contours:
        max_area = -1
        max_area_idx = 0
        
        for i, contour in enumerate(contours):
            area = cv2.contourArea(contour)
            if area > max_area:
                max_area = area
                max_area_idx = i

        x, y, w, h = cv2.boundingRect(contours[max_area_idx])
        rect = (x, y, w, h)

        # # tinggi_obj = 377
        # focal_length = 7.09
        # distance = (1/((1/focal_length)-(1/rect[3]))) 

        cv2.rectangle(frame, (rect[0], rect[1]), (rect[0] + rect[2], rect[1] + rect[3]), (0, 255, 0), 2)
        cv2.putText(frame, f'Jarak: {37.79}', (rect[0], rect[1] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

        olah_direction(rect)

    else:
        print('Tidak terbaca orang-orang an')

    cv2.imshow('Man Hunter', frame)

# Contoh penggunaan
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    detect_and_display_color(frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
