#include <iostream>
#include <opencv4/opencv2/opencv.hpp>
using namespace std;
using namespace cv;

int main() {
    VideoCapture kamera(0);
    if(kamera.isOpened()){
        cerr << "Bismillah" << endl;
    }
    
    Mat frame;

    int score = 0;
    Scalar warnaPermen(255, 0, 0);
    Point posisiPermen(rand() % 640, rand() % 480);
    int diameterPermen = 10;

    while(true){
        kamera >> frame;

        Mat hsv, lim_color;
        Mat frame_clone =  frame.clone();

        cvtColor(frame, hsv, COLOR_BGR2HSV);
        inRange(hsv, Scalar(0,159,116), Scalar(179,255,168),lim_color);

        vector<vector<Point>> kontur;
        findContours(lim_color, kontur, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

        circle(frame_clone, posisiPermen, diameterPermen, warnaPermen, -1);

        for (size_t i = 0; i < kontur.size(); i++) {
            Rect box = cv::boundingRect(kontur[i]);
            rectangle(frame_clone, box, Scalar(255, 255, 255), 2);

            if (box.contains(posisiPermen)) {
                score++;
                posisiPermen = Point(rand() % 640, rand() % 480);
            }
        }

        putText(frame_clone, "SCORE: " + to_string(score), Point(10, 30), FONT_HERSHEY_SIMPLEX, 1, Scalar(255, 255, 255), 2);

        imshow("kamera",frame_clone);
        if(waitKey(30)== 32){
            break;
        }
    }
}