#include <iostream>
#include <opencv2/opencv.hpp>

int main() {
    cv::VideoCapture cap(0);
    if (!cap.isOpened()) {
        std::cerr << "Error: Cannot open camera" << std::endl;
        return -1;
    }

    int score = 0;
    cv::Scalar candyColor(255, 0, 0); // Warna permen
    cv::Point candyPos(rand() % 640, rand() % 480); // Posisi awal permen
    int candyRadius = 20; // Radius permen
    int netRadius = 30; // Radius jaring

    while (true) {
        cv::Mat frame;
        cap >> frame;

        // Gambar permen
        cv::circle(frame, candyPos, candyRadius, candyColor, -1);

        // Konversi ke grayscale dan kemudian ke HSV untuk deteksi warna
        cv::Mat hsv;
        cv::cvtColor(frame, hsv, cv::COLOR_BGR2HSV);

        // Definisikan rentang warna untuk deteksi titik (misalnya, warna hijau)
        cv::Scalar lowerBound(50, 100, 100);
        cv::Scalar upperBound(70, 255, 255);

        // Thresholding untuk mendapatkan mask
        cv::Mat mask;
        cv::inRange(hsv, lowerBound, upperBound, mask);

        // Temukan kontur dari titik yang terdeteksi
        std::vector<std::vector<cv::Point>> contours;
        cv::findContours(mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

        cv::Point netCenter(0, 0); // Posisi jaring

        // Jika ada kontur yang terdeteksi, ambil pusat dari kontur tersebut
        if (!contours.empty()) {
            // Ambil kontur terbesar
            double maxArea = 0;
            int maxContourIndex = -1;
            for (int i = 0; i < contours.size(); i++) {
                double area = cv::contourArea(contours[i]);
                if (area > maxArea) {
                    maxArea = area;
                    maxContourIndex = i;
                }
            }

            // Hitung momen untuk mendapatkan pusat dari kontur terbesar
            cv::Moments mu = cv::moments(contours[maxContourIndex]);
            netCenter = cv::Point(mu.m10 / mu.m00, mu.m01 / mu.m00);
        }

        // Gambar jaring
        if (netCenter.x > 0 && netCenter.y > 0) {
            cv::circle(frame, netCenter, netRadius, cv::Scalar(0, 255, 0), 2); // Gambar jaring
        }

        // Cek tumbukan
        if (cv::norm(candyPos - netCenter) <= (candyRadius + netRadius)) {
            score++;
            candyPos = cv::Point(rand() % 640, rand() % 480); // Pindahkan permen ke lokasi baru
        }

        // Tampilkan skor
        cv::putText(frame, "SCORE: " + std::to_string(score), cv::Point(10, 30),
                    cv::FONT_HERSHEY_SIMPLEX, 1, cv::Scalar(255, 255, 255), 2);

        // Tampilkan frame
        cv::imshow("Game", frame);

        // Keluar jika ada tombol ditekan
        if (cv::waitKey(30) >= 0) break;
    }

    return 0;
}