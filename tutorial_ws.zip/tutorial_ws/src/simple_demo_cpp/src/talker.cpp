#include "ros/ros.h"
#include "std_msgs/String.h"
#include "tutorial_messages/Message2.h"
#include <sstream>

int main(int argc, char **argv)
{
  ros::init(argc, argv, "talker");
  ros::NodeHandle n;
  // ros::Publisher chatter_pub = n.advertise<std_msgs::String>("chatter", 1000);
  ros::Publisher chatter_pub = n.advertise<tutorial_messages::Message2>("chatter", 1000);
  ros::Rate loop_rate(1); // 1 Hz
  int cnt = 0; 
  while (ros::ok())
  {
    tutorial_messages::Message2 msg;
    msg.increment = cnt += 2;
    msg.decrement = cnt -= 1;

    cnt++;
    // std_msgs::String msg;
    // std::stringstream ss;
    // ss << "Hello ROS " << cnt++;
    // msg.data = ss.str();

    // ROS_INFO("%s", msg.data.c_str());
    ROS_INFO("increment: %d, decrement: %d", msg.increment, msg.decrement);
    chatter_pub.publish(msg);

    ros::spinOnce();
    loop_rate.sleep();
  }

  return 0;
}