
"use strict";

let Message2 = require('./Message2.js');

module.exports = {
  Message2: Message2,
};
